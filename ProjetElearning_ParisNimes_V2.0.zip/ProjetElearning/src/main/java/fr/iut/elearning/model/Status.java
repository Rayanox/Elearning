package fr.iut.elearning.model;

public enum Status {

	Admin, Etudiant, Professeur, Visiteur, All
	
}
