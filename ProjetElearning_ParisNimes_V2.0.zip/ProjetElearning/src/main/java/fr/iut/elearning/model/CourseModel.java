package fr.iut.elearning.model;

public class CourseModel {
	
	private int id;
	private String nameCourse;
	
	public CourseModel(){
		
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNameCourse() {
		return nameCourse;
	}

	public void setNameCourse(String nameCourse) {
		this.nameCourse = nameCourse;
	}
	
	

}
